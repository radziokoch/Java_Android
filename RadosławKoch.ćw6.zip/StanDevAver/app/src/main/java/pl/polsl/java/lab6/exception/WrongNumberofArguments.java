/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.polsl.java.lab6.exception;

/**
 * Class which throws an expection when user pass the wrong number of argumets
 *
 * @author Radek
 * @version 1.0
 */
public final class WrongNumberofArguments extends Exception {

    /**
     * Constructor of class.
     *
     * @author Radek
     * @version 1.1
     */
    public WrongNumberofArguments() {
    }

    @Override
    public String getMessage() {
        return "Can't calculate \n";
    }
}