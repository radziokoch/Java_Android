package pl.polsl.java.lab6.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import pl.polsl.java.lab6.exception.WrongNumberofArguments;
import pl.polsl.java.lab6.model.Array;


import pl.polsl.java.lab6.R;

public class MainActivity extends AppCompatActivity {
    Array array;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button average = (Button) findViewById(R.id.button);
        Button median = (Button) findViewById(R.id.button2);
        Button standev = (Button) findViewById(R.id.button5);

        final EditText number  = (EditText) findViewById(R.id.editText4);

        average.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View org) {
                try {
                    String data = number.getText().toString();
                    array = new Array(data);
                    double aver = 0;
                    try
                    {
                        aver = array.calculateAverage();
                    }
                    catch (WrongNumberofArguments e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                    Toast.makeText(getApplicationContext(), "średnia wynosi " + aver, Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });
        median.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View org) {
                try {
                    String data = number.getText().toString();
                    array = new Array(data);
                    double medi = 0;
                    try
                    {
                         medi = array.calculateMedian();
                    }
                    catch (WrongNumberofArguments e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
               /* EditText et = findViewById(R.id.editText);
                String name = String.valueOf(et.getText());
                String text = name.isEmpty() ?
                        "Najpierw sie  przedstaw":
                        "Witam cie " + name;*/

                    Toast.makeText(getApplicationContext(), "mediana wynosi " + medi, Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });

        standev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View org) {
                try {
                    String data = number.getText().toString();
                    array = new Array(data);
                    double stan = 0;
                    try
                    {
                        stan = array.calculateStandardDevation();
                    }
                    catch (WrongNumberofArguments e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                    Toast.makeText(getApplicationContext(), "odchylenie standardowe wynosi " + stan, Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
}
