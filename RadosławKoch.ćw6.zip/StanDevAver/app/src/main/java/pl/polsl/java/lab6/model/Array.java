/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.polsl.java.lab6.model;

import pl.polsl.java.lab6.exception.WrongNumberofArguments;
import java.util.*;

/**
 * Class which create array and manage array's operation
 *
 * @author Radek
 * @version 1.1
 */
public class Array {

    private List<Double> stringOfNumbers = new ArrayList<>();

    /**
     * @return size of array
     * @author Radek
     * @version 1.1
     */
    public int getSize() {
        return stringOfNumbers.size();
    }

    /**
     * Constructor which create array (with conversion from String[] to Double)
     * )
     *
     * @param stringOfData is a String [] of numbers
     * @author Radek
     * @version 1.1
     */
    public Array(String[] stringOfData) {

        for (String argument : stringOfData) {
            try {
                stringOfNumbers.add(Double.parseDouble(argument));
            } /**
             * Cathing the error in conversion
             */
            catch (NumberFormatException f) {
                System.out.println("Among the string is the word");

            }
        }
    }

    /**
     * Constructor which create array (with conversion from String to Double) )
     *
     * @param data is a String of numbers
     * @author Radek
     * @version 1.1
     */
    public Array(String data) {
        String[] stringOfData = data.split(",");
        for (String argument : stringOfData) {
            try {
                stringOfNumbers.add(Double.parseDouble(argument));
            } /**
             * Cathing the error in conversion
             */
            catch (NumberFormatException f) {
                System.out.println("Among the string is the word");

            }
        }
    }

    /**
     * Method which calculate average
     *
     * @author Radek
     * @version 1.1
     * @return average
     * @throws pl.polsl.java.lab6.exception.WrongNumberofArguments
     */
    public double calculateAverage() throws WrongNumberofArguments {

        if (stringOfNumbers.size() <= 0) {
            throw new WrongNumberofArguments();
        }
        double total = 0;

        for (int i = 0; i < stringOfNumbers.size(); i++) {
            total = total + stringOfNumbers.get(i);
        }
        double average = total / stringOfNumbers.size();
        return average;
    }

    /**
     * Method which calculate median
     *
     * @author Radek
     * @version 1.1
     * @return median
     * @throws pl.polsl.java.lab6.exception.WrongNumberofArguments
     */
    public double calculateMedian() throws WrongNumberofArguments {

        if (stringOfNumbers.size() <= 0) {
            throw new WrongNumberofArguments();
        }

        double median = 0;
        Collections.sort(stringOfNumbers);
        if (stringOfNumbers.size() % 2 == 0) {
            median = (stringOfNumbers.get((stringOfNumbers.size() / 2) - 1) + stringOfNumbers.get(stringOfNumbers.size() / 2)) / 2;
        } else {
            median = stringOfNumbers.get(stringOfNumbers.size() / 2);
        }
        return median;

    }

    /**
     * Method which calculate standard devation
     *
     * @author Radek
     * @version 1.1
     * @return
     * @throws pl.polsl.java.lab6.exception.WrongNumberofArguments
     */
    public double calculateStandardDevation() throws WrongNumberofArguments {
        if (stringOfNumbers.size() <= 1) {
            throw new WrongNumberofArguments();
        }

        double counter = 0;
        double average = calculateAverage();
        for (int i = 0; i < stringOfNumbers.size(); i++) {
            counter = counter + Math.pow(stringOfNumbers.get(i) - average, 2);
        }
        return Math.sqrt(counter / (stringOfNumbers.size() - 1));

    }
}

